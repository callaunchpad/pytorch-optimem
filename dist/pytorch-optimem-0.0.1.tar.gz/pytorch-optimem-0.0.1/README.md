# pytorch-optimem
A Python package for reducing memory footprint of PyTorch models
